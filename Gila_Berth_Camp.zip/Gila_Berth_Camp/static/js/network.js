getNetworkDetails = function(id){ 
    debugger;
    var popUpContainer = $("#network-grid");

    //var gridDom = $("#" + id);
    popUpContainer.dialog ({
        autoOpen: false,
        height: 600,
        width: 700,
        create:function(eve, ui){
            debugger;
        },
                 open: function(eve, ui){
            debugger;
            var grid = $("#network-details"), ht = grid.parent().height() - 5, wd = grid.parent().width();
                grid.pqGrid({
			selectionModel:{type:"row"},
			autoSizeInterval: 0, 			scrollModel: { autoFit: true }, 			width: "auto", 			height: "100%-30",
                    	freezeCols:1,
                    	editable:true,
			collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

                    	colModel: getNetworkDetailsColumn(),
                    	dataModel: getNetworkDataModel(),
                    	editModel: {clicksToEdit: 2},
                    render: function(eve,ui){
                         var $toolbar = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-top", this));
                         var $toolbar1 = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-bottom", this));     
                        $("<span>Edit Network</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            edit_network();
                        });
 		                        $("<span>Enable Wake Up LAN</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            enable_wakeup();
                        });
	                        $("<span>Disable Wake Up LAN</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            disable_wakeup();
                        });


        }
                   
                });
            
        },
       
        close: function(){
            debugger;
            $("#network-details").pqGrid("destroy");
        },
        show: {
            //effect: "blind",
            duration: 100
        },
        hide: {
            //effect: "explode",
            duration: 100
        }
    }).dialog( "open" );
    
}


enable_wakeup = function(){
    var $grid = $("#network-details");
    //alert(getRowIndx());
    var rowIndx = getNetworkRowIndx();
            if (rowIndx != null) {
                //debugger;
                var DM = $grid.pqGrid("option", "dataModel");
                var data = DM.data;
                var row = data[rowIndx];
                debugger;
                var name = row.port;
                alert(name);
                $.ajax({
                 type:"POST",
                 url:"../enable_wakeup/",
                 data: {
                        //csrfmiddlewaretoken: "{{ csrf_token }}",
                        port_name: name // from form
                        },
                        //contentType: "application/text; charset=utf-8",
              dataType: "text",
              success: function(data) {
              //debugger;
              //$("#vol_create").dialog('close');
              $("#network-details").pqGrid("refreshDataAndView" );
         },
    error: function(data){
        //debugger;
        alert("fail");
            
            }
        });
	 //DM.data.splice(rowIndx, 1);
                //debugger;
                $grid.pqGrid("refreshDataAndView");
                $grid.pqGrid("setSelection", {
                    rowIndx: rowIndx
                });


            }

}

disable_wakeup = function(){
    var $grid = $("#network-details");
    //alert(getRowIndx());
    var rowIndx = getNetworkRowIndx();
            if (rowIndx != null) {
                //debugger;
                var DM = $grid.pqGrid("option", "dataModel");
                var data = DM.data;
                var row = data[rowIndx];
                debugger;
                var name = row.port;
                alert(name);
                $.ajax({
                 type:"POST",
                 url:"../disable_wakeup/",
                 data: {
                        //csrfmiddlewaretoken: "{{ csrf_token }}",
                        port_name: name // from form
                        },
                        //contentType: "application/text; charset=utf-8",
              dataType: "text",
              success: function(data) {
              //debugger;
              //$("#vol_create").dialog('close');
              $("#network-details").pqGrid("refreshDataAndView" );
         },
    error: function(data){
        //debugger;
        alert("fail");

            }
        });
         //DM.data.splice(rowIndx, 1);
                //debugger;
                $grid.pqGrid("refreshDataAndView");
                $grid.pqGrid("setSelection", {
                    rowIndx: rowIndx
                });

}
}

getNetworkDetailsColumn = function(){
    return [
        {
            title: "IP", width: 100, dataIndx: "ip", editable: false
        },
        {
            title: "port", width: 100, dataIndx: "port", editable: false
        },
        {
            title: "MTU", width: 100, dataIndx: "mtu", editable: false
        },
        {
            title: "mode", width: 100, dataIndx: "mode", editable: false
        }
       
    ];
}

getNetworkDataModel = function(){
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function(){
            return {url: '../data_network/'}
        },
        getData: function (dataJSON) {
            //var data=                
            return { curPage: dataJSON.curPage, totalRecords: dataJSON.totalRecords, data: dataJSON.data };                
        }
    };
}

function edit_network() {
     var $grid = $("#network-details"),
        rowIndx = getNetworkRowIndx(),
        dataModel, services, row;

        if(rowIndx === undefined || rowIndx === null ){
            return;
        }

        dataModel = $grid.pqGrid("option", "dataModel");
        row = dataModel.data[rowIndx];
        //services =[ row.wiki, row.cifs, row.ftp, row.nfs, row.rb, row.ms, row.afp, row.webdav, row.encrypt ];

       var popUpContainer = $("#network_edit");
       popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,

        buttons :{
            Confirm: function(){
                
                var me = $(this);
                network_edit_confirmed(row.port);
            },
            Cancel: function () {
            $(this).dialog("close");
            }
        },


        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            html = [
            '<div class="confirm">',
                "<h1>IP Address Settings:LAN Port 1</h1>",
                '<div class="body-content-modal">', 
                 '<form id ="net_edit">',
  
                '<p>DHCP: <br/> ',
                '<span class="text-input-pop" style="margin-left:40px;"><input type="radio" onClick="myFunctionenable() " checked name="dhcp" value="dhcp" class="text-add" /> Enable</span>',
                '<span class="text-input-pop" style="margin-left:20px;"><input type="radio" onClick="myFunctiondisable()" name="dhcp" value="static" class="text-add" /> Disable</span>',
                '</p>',
  
  '<p>IP Address: * <br/>', 
        '<span class="text-input-pop"><input type="text" id="ipadd" value="'+row.ip+'" disabled class="text-add" /></span>',
  '</p>',
  
  '<p>Subnet Mask: * <br/> ',
        '<span class="text-input-pop"><input type="text" id="submas" value="255.255.255.0" disabled="true" class="text-add" /></span>',
  '</p>',

          '<p>Primary DNS Server <br/> ',
        '<span class="text-input-pop"><input type="text" disabled  id="pds" class="text-add" /></span>',
        '</p>',

  '<p>Ethernet Frame Size:<br/> ',
    '<span class="text-input-pop">',
        '<select id ="mtu" style="width:40%;">',
            '<option>1500</option>',
            '<option>4084</option>',
            '<option>7404</option>',
            '<option>9216</option>',
        '</select>',
    '</span>',
    '<span class="text-input-pop">Bytes</span>',
  '</p>',
  
  '<p style="border:#666 1px solid;padding:2%;width:91%;margin:10px auto;">Ethernet frame sizes of 1500-9216 bytes are supported. The stated size doesnt include 14 bytes of header and 4 bytes of FCS. The default frame size is 1500 bytes. Frame sizes of 1501 bytes or more are considered jumbo frames.',
  '</p>',
  '</form>',
'</div>' ];
            $("#network_edit_inner").html(html.join(""));
        },
        error: function(eve,ui){

          }}).dialog( "open" );
   }


function getNetworkRowIndx() {
        //var $grid = $("#grid_render_cells");

            //var obj = $grid.pqGrid("getSelection");
            //debugger;
            var $grid = $("#network-details");

            var arr = $grid.pqGrid("selection", {
                type: 'row',
                method: 'getSelection'
         });
            if (arr && arr.length > 0) {
                var rowIndx = arr[0].rowIndx;

                //if (rowIndx != null && colIndx == null) {
                return rowIndx;
            } else {
                alert("Select a row.");
                return null;
            }
        }

function network_edit_confirmed(port){
    str = '{"network":{"attrib":"'+$('input[name=dhcp]:checked', '#net_edit').val()+ '","ip":"'+$("#ipadd").val()+'","port":"'+port+'",'+'"netmask":"'+$('#submas').val()+'","dns":"'+$("#pds").val()+'","mtu":"'+$( "#mtu option:selected" ).text()+'"}}'; 
    debugger;  
    post_edit_network(str); 
}
function myFunctionenable() 
    {
    document.getElementById("ipadd").disabled=true;
    document.getElementById("submas").disabled=true;
    //document.getElementById("dga").disabled=true;
    document.getElementById("pds").disabled=true;
    //document.getElementById("sds").disabled=true;
    //document.getElementById("note").style.display="block";
    
    }

function myFunctiondisable() 
    {
    document.getElementById("ipadd").disabled=false;
    document.getElementById("submas").disabled=false;
    //document.getElementById("dga").disabled=false;
    document.getElementById("pds").disabled=false;
    //document.getElementById("sds").disabled=false;
    //document.getElementById("note").style.display="none";
    
    }

post_edit_network  =function(inpu){
    //console.log(sharedfolder);
    $.ajax({
                 type:"POST",
                 url:"../edit_network/",
                 data: { edit_network : inpu },
                        //contentType: "application/text; charset=utf-8",
              dataType: "json",
              
         success: function(data) {
        //debugger;
        $("#network_edit").dialog('close');
        $("#network-details").pqGrid("refreshDataAndView" );
    },
    error: function(data){
        $("#network_edit").dialog('close');
        $("#network-details").pqGrid("refreshDataAndView" );
        //debugger;
        alert("fail");
            
            }
        });    //$.post('../create_folder/',sharedfolder,function(){.fail(function(){debugger;})});
    //$.post("../create_volume/",{'sf':sharedfolder});
//var jsonquery = JSON.stringify(sharedfolder);
// $.ajax({
//     url: '../create_folder/',
//     type: 'POST',
//     contentType: 'application/json; charset=utf-8',
//     data: $.toJSON(sharedfolder),
//     dataType: 'text',
//     success: function(result) {
//         alert(result.Result);
//     }
// });
            return false;
}
