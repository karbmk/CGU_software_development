// JavaScript Document

$(document).ready(function(){
	 $("#info-dropdown").click(function()
		{
		$("#dropdown-info").toggle(200);
		});


 	$('body').click(function(e) {
        if (!$(e.target).closest('#info-dropdown').length){
           $("#dropdown-info").hide();
        }
	});
	
	
	 $("#dropdown-restart").click(function()
		{
		$("#dropdown-shutdown").toggle(200);
		});


 	$('body').click(function(e) {
        if (!$(e.target).closest('#dropdown-restart').length){
           $("#dropdown-shutdown").hide();
        }
	});

		$('#main-lang').click(function()
		{
		$('#lang-dd').toggle(100);
		});
		
        $('#eng-lang').click(function()
		{
		$('#main-lang').html('English');
		$('#lang-dd').hide(100);		
		});
		
		 $('#jap-lang').click(function()
		{
		$('#main-lang').html('Japanese');	
		$('#lang-dd').hide(100);	
		});
		
		
// Links Code

$('#filesharing-click').click(function()
	{
	$('#filesharing').show();	
	$('#home').hide();
	});	

$('#filesharing-back').click(function()
	{
	$('#filesharing').hide();	
	$('#home').show();
	});	


$('#drives-click').click(function()
	{
	$('#drives').show();	
	$('#home').hide();
	});	

$('#drives-back').click(function()
	{
	$('#drives').hide();	
	$('#home').show();
	});	
	

$('#services-click').click(function()
	{
	$('#services').show();	
	$('#home').hide();
	});	

$('#services-back').click(function()
	{
	$('#services').hide();	
	$('#home').show();
	});	

$('#webservices-click').click(function()
	{
	$('#webservices').show();	
	$('#home').hide();
	});	

$('#webservices-back').click(function()
	{
	$('#webservices').hide();	
	$('#home').show();
	});	
	
$('#applications-click').click(function()
	{
	$('#applications').show();	
	$('#home').hide();
	});	

$('#applications-back').click(function()
	{
	$('#applications').hide();	
	$('#home').show();
	});	

$('#network-click').click(function()
	{
	$('#network').show();	
	$('#home').hide();
	});	

$('#network-back').click(function()
	{
	$('#network').hide();	
	$('#home').show();
	});		
	
$('#backup-click').click(function()
	{
	$('#backup').show();	
	$('#home').hide();
	});	

$('#backup-back').click(function()
	{
	$('#backup').hide();	
	$('#home').show();
	});
	
$('#management-click').click(function()
	{
	$('#management').show();	
	$('#home').hide();
	});	

$('#management-back').click(function()
	{
	$('#management').hide();	
	$('#home').show();
	});

 });
