getManagementDetails = function(id) {
    
    var popUpContainer = $("#management-grid");

    //var gridDom = $("#" + id);
    popUpContainer.dialog({
        autoOpen: false,
        height: 600,
        width: 700,
        modal: true,
        //draggable: true,
        create: function(eve, ui) {
            debugger;
        },
        open: function(eve, ui) {
            
	
	   var grid = $("#management-details"),
		grid1 = $("#management-details1"),
		grid2 = $("#management-details2"),
		ht = $(this).height() - 5,
                wd = $(this).width() - 30;
		
		debugger;
		//tabDiv.tabs('option', 'active', 1);
            grid.parent().css('padding', '2px');
            grid.pqGrid({
		selectionModel:{type:"row"},
		collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

                modal:true,
		autoSizeInterval: 0, scrollModel: { autoFit: true }, 
		width: 'auto', height: ht,
                colModel: getManagementDetailsColumn(),
                dataModel: getManagementDataModel()
            });
           grid.children('.pq-grid-top').children('.pq-grid-title').hide();
    
	    //tabDiv.tabs('option', 'active', 2);
            grid1.parent().css('padding', '2px');
            grid1.pqGrid({
		selectionModel:{type:"row"},
		collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

                modal:true,
		autoSizeInterval: 0, scrollModel: { autoFit: true }, 
		width: 'auto', height: ht,
                colModel: getManagementDetailsColumn1(),
                dataModel: getManagementDataModel1(),
                render: function(eve, ui) {
			
                }
            });
            grid1.children('.pq-grid-top').children('.pq-grid-title').hide();

		//tabDiv.tabs('option', 'active', 3);
            grid2.parent().css('padding', '2px');
            grid2.pqGrid({
		selectionModel:{type:"row"},
		collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

		autoSizeInterval: 0, scrollModel: { autoFit: true }, 
		width: 'auto', height: ht,
		modal:true,
                colModel: getManagementDetailsColumn2(),
                dataModel: getManagementDataModel2()
            });
            grid2.children('.pq-grid-top').children('.pq-grid-title').hide();
	
		//tabDiv.tabs('option', 'active', 1);
	    
        },

        close: function() {
            debugger;
            $("#management-details").pqGrid("destroy");
            $("#management-details1").pqGrid("destroy");
            $("#management-details2").pqGrid("destroy");
        },
        show: {
            //effect: "blind",
            duration: 100
        },
        hide: {
            //effect: "explode",
            duration: 100
        }
/*,
        resizeStop: function(eve, ui) {
            var grid = $("#management-details");
            var grid1 = $("#management-details1");
            var grid2 = $("#management-details2");

        }
*/
    }).dialog("open");
	$("#tabs2").tabs({
		active: 1,
		activate: function(eve, ui){
			//debugger;
			ui.newPanel.children().pqGrid('refresh');
		}
	});
	$("#tabs2").css('display', 'block');
}

getManagementDetailsColumn = function() {
    return [{
            title: "Character Encoding",
            width: 100,
            dataIndx: "character encoding",
            editable: false
        }, {
            title: "Language",
            width: 100,
            dataIndx: "Display Language",
            editable: false
        }


    ];
}


getManagementDetailsColumn1 = function() {
    return [{
            title: "Hostname",
            width: 100,
            dataIndx: "hostname",
            editable: false
        }, {
            title: "Description",
            width: 100,
            dataIndx: "description",
            editable: false
        }


    ];
}


getManagementDetailsColumn2 = function() {
    return [{
            title: "Date/Time",
            width: 100,
            dataIndx: "Date/Time",
            editable: false
        }, {
            title: "Use Default NTP Server",
            width: 100,
            dataIndx: "Use Default NTP Server",
            editable: false
        }, {
            title: "Frequency",
            width: 100,
            dataIndx: "Frequency",
            editable: false
        }, {
            title: "Time",
            width: 100,
            dataIndx: "Time",
            editable: false
        }



    ];
}



getManagementDataModel = function() {
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function() {
            return {
                url: '../management_func/'
            }
        },
        getData: function(dataJSON) {
            //var data=                
            return {
                curPage: dataJSON.curPage,
                totalRecords: dataJSON.totalRecords,
                data: dataJSON.data
            };
        }
    };
}


getManagementDataModel1 = function() {
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function() {
            return {
                url: '../management_func1/'
            }
        },
        getData: function(dataJSON) {
            //var data=                
            return {
                curPage: dataJSON.curPage,
                totalRecords: dataJSON.totalRecords,
                data: dataJSON.data
            };
        }
    };
}


getManagementDataModel2 = function() {
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function() {
            return {
                url: '../management_func2/'
            }
        },
        getData: function(dataJSON) {
            //var data=                
            return {
                curPage: dataJSON.curPage,
                totalRecords: dataJSON.totalRecords,
                data: dataJSON.data
            };
        }
    };
}
