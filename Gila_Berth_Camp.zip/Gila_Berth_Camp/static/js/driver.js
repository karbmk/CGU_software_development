getDiskDetails = function(id){ 
    //var gridDom = $("#" + id);
    var popUpContainer = $("#popup-grid_drives");
    
    popUpContainer.dialog ({
        autoOpen: false,
        height: 600,
        width: 700,
        
        open: function(eve, ui){
           
            var grid = $("#driver-details"), ht = grid.parent().height() - 5, wd = grid.parent().width();
                grid.pqGrid({
			autoSizeInterval: 0, 			width: "auto", 			height: "100%-30",
                    	freezeCols:1,
                    	selectionModel: { type: 'row' },
                    	editable:true,
                   	//collapsible:false,
                   
                  numberCell:{resizable:true,title:"#",width:30,minWidth:30},
                 editor: {type: 'textbox'},
            	resizable:true,
            	scrollModel:{autoFit:true, theme:true},
		collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

                    colModel: getDiskDetailsColumn(),
                    dataModel: getDiskDataModel(),
                    editModel: {clicksToEdit: 2},
                  // selectionModel: {mode: 'single'},
                   render: function(eve, ui){
                        var rowData = ui.rowData;
                        var $toolbar = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-top", this));
                        $("<span>Claim Disk</span>").appendTo($toolbar).button({
                            icons: {
                                //primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            claimdisk();
                        });
                        $("<span>Remove Disk</span>").appendTo($toolbar).button({
                            icons: {
                                //primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                           //deletevolume();
                        });
		$("<span>S.M.A.R.T</span>").appendTo($toolbar).button({
                            icons: {
                                //primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                           smart();
                        });
                    }
                });
            
        },
        close: function(){
            $("#driver-details").pqGrid("destroy");
        },
        show: {
            duration: 100
        },
        hide: {
            duration: 100
        }
    }).dialog( "open" );
    
}

getDiskDetailsColumn = function(){
    return [
        {
            title: "Disk Name", width: 100, dataIndx: "name", editable: false
        },
        {
            title: "Size", width: 100, dataIndx: "size", editable: false
        },
        {
            title: "Status", width: 100, dataIndx: "status", editable: false
        },
        {
            title: "Vendor", width: 100, dataIndx: "vendor", editable: false
        },
        {
            title: "Volumes", width: 100, dataIndx: "volume", editable: false
        }
    ];
}

getSmartDetailsColumn = function(){
    return [
        {
            title: "Id", width: 100, dataIndx: "id", editable: false
        },
        {
            title: "Attrib", width: 100, dataIndx: "attrib", editable: false
        },
        {
            title: "Flag", width: 100, dataIndx: "flag", editable: false
        },
        {
            title: "Value", width: 100, dataIndx: "value", editable: false
        },
        {
            title: "Worst", width: 100, dataIndx: "worst", editable: false
        },
	   {
            title: "Thrash", width: 100, dataIndx: "thresh", editable: false
        },
	{
            title: "Type", width: 100, dataIndx: "type", editable: false
        },
	{
            title: "Updated", width: 100, dataIndx: "updated", editable: false
        },
	{
            title: "Whenfailed", width: 100, dataIndx: "whenfailed", editable: false
        },
	{
            title: "Rawvalue", width: 100, dataIndx: "rawvalue", editable: false
        }	
    ];
}


getDiskDataModel = function(){
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function(){
            return {url: '../data_disk/'}
        },
        getData: function (dataJSON) {
            //var data=                
            return { curPage: dataJSON.curPage, totalRecords: dataJSON.totalRecords, data: dataJSON.data };                
        }
    };
}

getSmartDataModel = function(){
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        getUrl: function(){
            return {url: '../smart_disk/'}
        },
        getData: function (dataJSON) {
            //var data=                
            return { curPage: dataJSON.curPage, totalRecords: dataJSON.totalRecords, data: dataJSON.data };                
        }
    };
}

claimdisk = function(){
    var $grid = $("#driver-details");
    //alert(getRowIndx());
    var rowIndx = getDriveRowIndx();
            if (rowIndx != null) {
                //debugger;
                var DM = $grid.pqGrid("option", "dataModel");
                var data = DM.data;
                var row = data[rowIndx];
                var name = '{"DISK":{"name":"'+row.name+'"}}';
                //alert(rowIndx);
                $.ajax({
                 type:"POST",
                 url:"../claim_disk/",
                 data: {
                        //csrfmiddlewaretoken: "{{ csrf_token }}",
                        disk_name: name // from form
                        },
                        //contentType: "application/text; charset=utf-8",
              dataType: "text",
              success: function(data) {
              //debugger;
              //$("#vol_create").dialog('close');
              $("#disk-details").pqGrid("refreshDataAndView" );
         },
    error: function(data){
        //debugger;
        alert("fail");
            
            }
        });
           // return false;

                //DM.data.splice(rowIndx, 1);
                //debugger;
                $grid.pqGrid("refreshDataAndView");
                $grid.pqGrid("setSelection", {
                    rowIndx: rowIndx
                });


            } 

}


smart = function(){
	debugger;
	var model;
	 var device;
var serial;
var firmware;
var usercap;
    var $grid = $("#driver-details"),
        rowIndx = getDriveRowIndx(),
        dataModel, services, row;

        if(rowIndx === undefined || rowIndx === null ){
            return;
        }

        dataModel = $grid.pqGrid("option", "dataModel");
        row = dataModel.data[rowIndx];
        //services =[ row.wiki, row.cifs, row.ftp, row.nfs, row.rb, row.ms, row.afp, row.webdav, row.encrypt ];
debugger;
    var popUpContainer = $("#smart_details");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 600,
        width: 700,
        modal:true,
        draggable: true,
	selectionModel:{type:"row"},
        open: function(eve, ui){
            var grid = $("#smart_details_inner"), ht = grid.parent().height() - 5, wd = grid.parent().width();
                grid.pqGrid({
			autoSizeInterval: 0,                    width: "auto",                  height: "100%-30",
                    freezeCols:1,
                    selectionModel: { type: 'row' },
                    editable:true,
			collapsible:false,
                    colModel: getSmartDetailsColumn(),
                    dataModel: getSmartDataModel(),
                    editModel: {clicksToEdit: 2},
                   render: function(eve, ui){
                        var rowData = ui.rowData;
                         var new_model;

                        $.ajax({
        			type: 'GET',
        			url:"../smart_disk1",
        			success: function(response){
            				var obj = $.parseJSON(response);
        				model = obj.data[0].ModelFamily;
        

        				device= obj.data[0].DeviceModel;
        				serial= obj.data[0].SerialNumber;
        				firmware= obj.data[0].FirmwareVersion;
        				usercap= obj.data[0].UserCapacity;
        //document.getElementById($(".pq-grid-top", this)).innerHTML=model;
        //document.getElementById("smart_details").innerHTML=device;
            //$('#smart_details').dialog('option', 'title', model);
//var $toolbar = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud '></div>").appendTo($(".pq-grid-top", this));
                        //window.alert(model);
       					new_model= out(model,device,serial,firmware,usercap);

        
               
    					//window.alert(obj.data[0].ModelFamily);
          
        
            
        			},
        			error: function(){

        			}
    			});
    			debugger;
    			function out(mod, device,serial,firmware,usercap){ 
				var diskInfoElem = $('#smart_disk_info'), popUpHt = popUpContainer.height();		

				diskInfoElem.html(
					[
						"<p style='font-size:14px; line-height:10px;'>ModelFamily : "+mod+"</p>",
						"<p style='font-size:14px; line-height:10px;'>DeviceModel : "+device+"</p>",
						"<p style='font-size:14px; line-height:10px;'>SerialNumber : "+serial+"</p>",
						"<p style='font-size:14px; line-height:10px;'>FirmwareVersion : "+firmware+"</p>",
						"<p style='font-size:14px; line-height:10px;'>UserCapacity : "+usercap+"</p>"
					].join("")
				);
				grid.pqGrid('option', 'height', (popUpHt - diskInfoElem.height() - 40));
				grid.pqGrid('refresh');

/* $("<span>Model Name</span>").appendTo($toolbar).html("<p>ModelFamily : "+mod+"</p>");
                            $("<span>Model Name</span>").appendTo($toolbar).html("<p>DeviceModel : "+device+"</p>");
                            $("<span>Model Name</span>").appendTo($toolbar).html("<p>SerialNumber : "+serial+"</p>");
                            $("<span>Model Name</span>").appendTo($toolbar).html("<p>FirmwareVersion : "+firmware+"</p>");
                            $("<span>Model Name</span>").appendTo($toolbar).html("<p>UserCapacity : "+usercap+"</p>");
*/
}
                        
                    }
                });
		

             

        },
        error: function(){
            debugger;

        }}).dialog( "open" );

}


function getDriveRowIndx() {
            //var $grid = $("#grid_render_cells");

            //var obj = $grid.pqGrid("getSelection");
            //debugger;
            var $grid = $("#driver-details");

            var arr = $grid.pqGrid("selection", {
                type: 'row',
                method: 'getSelection'
            });
            if (arr && arr.length > 0) {
                var rowIndx = arr[0].rowIndx;

                //if (rowIndx != null && colIndx == null) {
                return rowIndx;
            } else {
                alert("Select a row.");
                return null;
            }
        }
