getUserDetails = function(id){ 

   
    var popUpContainer = $("#popup-grid_user");

    popUpContainer = popUpContainer.dialog ({
        autoOpen: false,
	width: 700, 
	height: 500,
        modal:true,
        draggable: true,

        create:function(eve, ui){

        },
        
        open: function(eve, ui){
            debugger;
	    document.getElementById('tabs').style.display = "block";
            var grid = $("#user-details"), ht = $(this).height() - 5, wd = $(this).width() - 30; 
            grid.parent().css('padding', '2px');
            grid.pqGrid({
			autoSizeInterval: 0, scrollModel: { autoFit: false }, width: "auto", height: "100% - 10",
			selectionModel:{type:"row"},
		//	collapsible:false,
			modal:true,
			collapsible:{
                                on: false,
                                toggle: true,
                                collapsed: false
                        },

                    colModel: getUserDetailsColumn(),
                    dataModel: getUserDataModel(),
                    render: function(eve, ui){
                        var $toolbar = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-top", this));
			var $toolbar1 = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-bottom", this));
                        $("<span>Create User</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            addUser();
                        });

			$("<span>Import csv file</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-arrow-s"
                            }
                        }).click(function (evt) {
                            importCsv();
                        });

			$("<span>Delete User</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                            deleteUser();
                        });

			$("<span>Convert to external user</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-person"
                            }
                        }).click(function (evt) {
                            externalUser();
                        });

			$("<span>Select all</span>").appendTo($toolbar1).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            selectUser();
                        });

			$("<span>Unselect all</span>").appendTo($toolbar1).button({
                            icons: {
                                primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                            unselectUser();
                        });
                    }
                });
            grid.children('.pq-grid-top').children('.pq-grid-title').hide();






var grid1 = $("#user-details1"), ht = $(this).height() , wd = $(this).width() - 30; 
            grid1.parent().css('padding', '2px');
            grid1.pqGrid({
			selectionModel:{type:"row"},
		//	collapsible:false,
		 width: "auto", height: ht,
			autoSizeInterval: 0, scrollModel: { autoFit: true },
			modal:true,
                    colModel: getUserDetailsColumn_ext(),
                    dataModel: getUserDataModel_ext(),
                    render: function(eve, ui){
                        var $toolbar = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-top", this));
			var $toolbar1 = $("<div class='pq-grid-toolbar pq-grid-toolbar-crud'></div>").appendTo($(".pq-grid-bottom", this));
                        

			$("<span>Delete User</span>").appendTo($toolbar).button({
                            icons: {
                                primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                            deleteExtUser();
                        });

			

			$("<span>Select all</span>").appendTo($toolbar1).button({
                            icons: {
                                primary: "ui-icon-circle-plus"
                            }
                        }).click(function (evt) {
                            selectExtUser();
                        });

			$("<span>Unselect all</span>").appendTo($toolbar1).button({
                            icons: {
                                primary: "ui-icon-circle-minus"
                            }
                        }).click(function (evt) {
                            unselectExtUser();
                        });
                    }
                });
            grid1.children('.pq-grid-top').children('.pq-grid-title').hide();

        },
        close: function(){
            
            $("#user-details").pqGrid("destroy");
	    $("#user-details1").pqGrid("destroy");
        },
        show: {
            //effect: "blind",
            duration: 100
        },
        hide: {
           // effect: "explode",
            duration: 100
        },
        resizeStop: function(eve, ui){
            var grid = $("#user-details");
	    var grid1 = $("#user-details1");

        }

    });
     //  $("#tabs2").tabs({
     //           active: 1,
    //            activate: function(eve, ui){
    //                    //debugger;
    //                    ui.newPanel.children().pqGrid('refresh');
    //            }
    //    });
    //    $("#tabs1").css('display', 'block');


 
popUpContainer.dialog( "open" );
$( "#tabs" ).tabs({heightStyle : "auto"});

    
}

getUserDetailsColumn = function(){
    return [
        {
            title: "User Name", width: 100, dataIndx: "userName", editable: false
        },
        {
            title: "Description", width: 200, dataIndx: "description", editable: false
        },
        {
            title: "Quota Alert Capacity", width: 160, dataIndx: "quotaalert", editable: false
        },
        {
            title: "Quota Capacity", width: 130, dataIndx: "quotacapacity", editable: false
        },
        {
            title: "Group", width: 100, dataIndx: "primaryGroup", editable: false
        },
        {
            title: "Groups", width: 100, dataIndx: "groups", editable: false , hidden: true
        },
        {
            title: "Email", width: 100, dataIndx: "email", editable: false, hidden:true
        },
        {
            title: "Password", width: 100, dataIndx: "password", editable: false, hidden: true
        },
        {
            title: "UserId", width: 100, dataIndx: "userId", editable: false, hidden: true
        },
        {
            title: "QuotaDisabled", width: 150, dataIndx: "quotaDisabled", editable: false
        }

	
    ];
}



getUserDetailsColumn_ext = function(){
    return [
        {
            title: "User Name", width: 100, dataIndx: "userName", editable: false
        },
        {
            title: "Description", width: 200, dataIndx: "description", editable: false
        },
        {
            title: "Quota Alert Capacity", width: 160, dataIndx: "quotaalert", editable: false
        },
        {
            title: "Quota Capacity", width: 130, dataIndx: "quotacapacity", editable: false
        },
        {
            title: "Group", width: 100, dataIndx: "primaryGroup", editable: false
        },
        {
            title: "Groups", width: 100, dataIndx: "groups", editable: false , hidden: true
        },
        {
            title: "Email", width: 100, dataIndx: "email", editable: false, hidden:true
        },
        {
            title: "Password", width: 100, dataIndx: "password", editable: false, hidden: true
        },
        {
            title: "UserId", width: 100, dataIndx: "userId", editable: false, hidden: true
        },
        {
            title: "QuotaDisabled", width: 150, dataIndx: "quotaDisabled", editable: false
        }


    ];
}





getUserDataModel = function(){
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        //paging: 'local',
        getUrl: function(){
            return {url: '../data_users/'}
        },
        getData: function (dataJSON) {
            //var data=                
            return { curPage: dataJSON.curPage, totalRecords: dataJSON.totalRecords, data: dataJSON.data };                
        }
    };
}


getUserDataModel_ext = function(){
    return {
        location: "remote",
        sorting: "local",
        dataType: "JSON",
        method: "GET",
        //paging: 'local',
        //getUrl: function(){
            //return {url: '../data_users/'}
       // },
        //getData: function (dataJSON) {
            //var data=                
         //   return { curPage: dataJSON.curPage, totalRecords: dataJSON.totalRecords, data: dataJSON.data };
       // }
    };
}



deleteExtUser = function(){
    debugger;
    var popUpContainer = $("#delete_extuser");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 600,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#delete_extuser_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
            //effect: "blind",
            duration: 100
        },
        
        hide: {
           // effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}


selectExtUser = function(){
    var popUpContainer = $("#extuser_select");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#extuser_select_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
           // effect: "blind",
            duration: 100
        },
        
        hide: {
          //  effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}


unselectExtUser = function(){
    var popUpContainer = $("#extuser_unselect");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#extuser_unselect_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
           // effect: "blind",
            duration: 100
        },
        
        hide: {
           // effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}



selectUser = function(){
    var popUpContainer = $("#user_select");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#user_select_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
            //effect: "blind",
            duration: 100
        },
        
        hide: {
           // effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}


unselectUser = function(){
    var popUpContainer = $("#user_unselect");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#user_unselect_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
            //effect: "blind",
            duration: 100
        },
        
        hide: {
           // effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}

importCsv = function(){
    // var popUpContainer = $("#csv_import");
    // popUpContainer.dialog ({
    //     autoOpen: false,
    //     height: 400,
    //     width: 500,
    //     modal:true,
    //     draggable: true,
    //     create:function(eve, ui){
    //         //todo code for after creation
    //     },
    //     open: function(eve, ui){
            
    //         $.ajax({
    //     type: 'GET',
    //     url:"../no_disks",
    //     success: function(response){
    //         var obj = $.parseJSON(response),
    //             diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
    //             html = "";

    //         var diskList = [], count = obj.count, i = 0;

    //         while(i < count){
    //             diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
    //             i++;
    //         }

    //         html = [
    //             "<div class=\"confirm\">",
    //                 "<p>",
    //                     "Name",
    //                     "<span class=\"text-input-pop\">",
    //                         "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
    //                     "</span>",
    //                 "</p>",
    //                 "<p>",
    //                     "Disk",
    //                     "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
    //                         diskList.join("<br />"),
    //                     "</div>",
    //                 "</p>",
    //                 "<p>",
    //                     "Raid Level <br />",
    //                     "<span class=\"text-input-pop\">",
    //                         "<select id =\"select_raid\">",
    //                             "<option value =\"99\">Span</option>",
    //                             "<option value =\"0\">0</option>",
    //                             "<option value =\"1\">1</option>",
    //                             "<option value =\"5\">5</option>",
    //                             "<option value =\"10\">10</option>",
    //                         "</select>",
    //                     "</span",
    //                 "</p>",
    //                 "<p>",
    //                     "FS <br />",
    //                     "<span class=\"text-input-pop\">",
    //                         "<select id =\"fs_type\">",
    //                             "<option value =\"ext3\">Ext 3</option>",
    //                             "<option value =\"ext4\">Ext 4</option>",
    //                             "<option value =\"xfs\">XFS</option>",
    //                         "</select>",
    //                     "</span",
    //                 "</p>",
    //                 "<p style=\"margin-bottom:4rem;\">",
    //                     "Size <br />",
    //                     "<span class=\"text-input-pop\">",
    //                         "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
    //                     "</span",
    //                 "</p>",
    //                 "</p>",
    //                 "<p style=\"margin-bottom:4rem;\">",
    //                     "<button id=\"cancel-dialog\">Cancel</button>",
    //                     "<button autofocus onclick =\"confirmed()\">Confirm</button>",
    //                 "</p>",
    //             "</div>"
    //         ];

    //          $("#csv_import_inner").html(html.join(""));
    //     },
    //     error: function(){

    //     }
    // });

    //     },
        
    //     show: {
    //         //effect: "blind",
    //         duration: 100
    //     },
        
    //     hide: {
    //         //effect: "explode",
    //         duration: 100
    //     },


    //     }).dialog( "open" );

}


deleteUser = function(){
     var $grid = $("#user-details");
    //alert(getRowIndx());
    var rowIndx = getUserRowIndx();
            if (rowIndx != null) {
                //debugger;
                var DM = $grid.pqGrid("option", "dataModel");
                var data = DM.data;
                var row = data[rowIndx];
    
        var quata_js = {
            disabled: "yes" ,
            quataAlert: "0",
            capacity: "0"
          };

          var user = {
            userName:row.userName  ,
            userId:"0",
            primaryGroup:row.primaryGroup ,
            groups:" ",
            email:row.email,
            passwd:" ",
            description:row.description,
            quata:quata_js

          };
          var final_js = { user : user};
          $.ajax({
                           type:"POST",
                           url:"../delete_user/",
                           data: { string : JSON.stringify(final_js) },
                                  //contentType: "application/text; charset=utf-8",
              dataType: "text",
              success: function(data) {
                  debugger;
                  //$("#user_create").dialog('close');
                  $("#user-details").pqGrid("refreshDataAndView" );
              },
              error: function(data){
                  debugger;
                  alert("fail");
                      
                      }
                  });
        //alert("Passwords Match!!!");
    }
    //return ;

        //  var final_js = { user : user};
          //var imp = '{"user":{"userName":"'+row.volumeName+'", "userid":"'+row.sharedFolderName+'", "primaryGroup":"'+row.ownerName+'", "groups":"'+row.uniqueID+'","email":"'+row.email+'","passwd":}}';
                //alert(rowIndx);
    //             $.ajax({
    //              type:"POST",
    //              url:"../delete_folder/",
    //              data: {
    //                     //csrfmiddlewaretoken: "{{ csrf_token }}",
    //                     folder_name: imp // from form
    //                     },
    //                     //contentType: "application/text; charset=utf-8",
    //           dataType: "text",
    //           success: function(data) {
    //           //debugger;
    //           //$("#vol_create").dialog('close');
    //           $("#user-details").pqGrid("refreshDataAndView" );
    //      },
    // error: function(data){
    //     //debugger;
    //     alert("fail");
            
    //         }
    //     });
    //        // return false;

    //             //DM.data.splice(rowIndx, 1);
    //             //debugger;
    //             $grid.pqGrid("refreshDataAndView");
    //             $grid.pqGrid("setSelection", {
    //                 rowIndx: rowIndx
    //             });



  

}

externalUser = function(){
    var popUpContainer = $("#ext_user");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){
            
            $.ajax({
        type: 'GET',
        url:"../no_disks",
        success: function(response){
            var obj = $.parseJSON(response),
                diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";

            var diskList = [], count = obj.count, i = 0;

            while(i < count){
                diskList.push("<span class=\"text-input-pop\"><input type=\"checkbox\" class=\"text-add3\" name= \"disk_check\" value=\"sd" +diskChar[i] + "\"/>disk" + i + "</span>");
                i++;
            }

            html = [
                "<div class=\"confirm\">",
                    "<p>",
                        "Name",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"text\" class=\"text-add\" id =\"vol_name\"/>",
                        "</span>",
                    "</p>",
                    "<p>",
                        "Disk",
                        "<div class=\"raid-disk-cont\" style=\"margin:0 3rem;\">",
                            diskList.join("<br />"),
                        "</div>",
                    "</p>",
                    "<p>",
                        "Raid Level <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"select_raid\">",
                                "<option value =\"99\">Span</option>",
                                "<option value =\"0\">0</option>",
                                "<option value =\"1\">1</option>",
                                "<option value =\"5\">5</option>",
                                "<option value =\"10\">10</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p>",
                        "FS <br />",
                        "<span class=\"text-input-pop\">",
                            "<select id =\"fs_type\">",
                                "<option value =\"ext3\">Ext 3</option>",
                                "<option value =\"ext4\">Ext 4</option>",
                                "<option value =\"xfs\">XFS</option>",
                            "</select>",
                        "</span",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "Size <br />",
                        "<span class=\"text-input-pop\">",
                            "<input type=\"number\" class=\"text-add\" id=\"size\" value=\"1\" min=\"1\" max=\"100\"/> GB",
                        "</span",
                    "</p>",
                    "</p>",
                    "<p style=\"margin-bottom:4rem;\">",
                        "<button id=\"cancel-dialog\">Cancel</button>",
                        "<button autofocus onclick =\"confirmed()\">Confirm</button>",
                    "</p>",
                "</div>"
            ];

             $("#ext_user_inner").html(html.join(""));
        },
        error: function(){

        }
    });

        },
        
        show: {
           // effect: "blind",
            duration: 100
        },
        
        hide: {
           // effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}


addUser = function(){
    var popUpContainer = $("#user_create");
    popUpContainer.dialog ({
        autoOpen: false,
        height: 400,
        width: 500,
        modal:true,
        draggable: true,
        resizable: false,
        buttons :{
            Confirm: function(){
                debugger;
                var me = $(this);
                confirmClicked($("#un").val(),$('#groups').find(":selected").text(),$("#em").val(),$("#pwd").val(),$("#desc").val());
                //volume_edit_confirmed(row.port);
            },
            Cancel: function () {
            $(this).dialog("close");
            }
        },

        create:function(eve, ui){
            //todo code for after creation
        },
        open: function(eve, ui){

            $.ajax({
        type: 'GET',
        url:"../group_list",
        success: function(response){
            debugger;
            var obj = $.parseJSON(response),
                //diskChar = "abcdefghijklmnopqrstuvwxyz".split(""),
                html = "";
                debugger;

            var groupList = obj.group, count = obj.count, i = 0;
            var groupListstr =[]
            for (var i=0; i<groupList.length;i++)
            {
                groupListstr.push("<option value = \""+groupList[i]+"\">"+groupList[i]+"</option>");

            }
            debugger;

            html = [ '<div class="confirm" >',
              '<h1>','Create User','</h1>',
              
              
             '<div class="body-content-modal">', 
               
             '<!-- Left Container -->',  
               '<div class="modal-left-cont">',
               '<p>UserName* <br/>',
                    '<span class="text-input-pop">',
                        '<input type="text" id ="un" class="text-add" />',
                        
                '</span>',
              '</p>',
              '<p>User ID:<br/>',
                'Enter a number from 1000 to 1999.',
                '<br/>', 
                    '<span class="text-input-pop">','<input type="text" value="1" disabled class="text-add" style="width:25% !important;" /></span>',
              '</p>',
              '<p>Email <br/>',
                    '<span class="text-input-pop">',
                        '<input type="text" id ="em" class="text-add" />',
                        
                '</span>',
              '</p>',
              
              '<p>Password* <br/>',
                    '<span class="text-input-pop">',
                        '<input type="password" class="text-add" id="pass1" />',
                        
                '</span>',
              '</p>',
              '<p>Confirm Password* <br/>', 
                    '<span class="text-input-pop">',
                        '<input type="password" id ="pwd"class="text-add"  />',
                        
                '</span>',
              '</p>',
              
              
              
              '<p>Description:<br/>', 
                    '<span class="text-input-pop">',
                        '<textarea id = "desc" style="resize:none;">',
                        
                        '</textarea>',
                    '</span>',
              '</p>',
              
              '<p>Quota:<br/> <br/>', 
                    '<input type="radio" name="quota" checked onClick="disablequota()" /> Disable <br/> <br/>',
              
                    '<input type="radio" name="quota" onClick="enablequota()" /> Enable(Units: GB) <br/>',
                     '<span class="text-input-pop">',
                        '<div style="text-align:right; font-size:12px; margin-bottom:10px;">',
                            'Quota Alert Capacity: <input type="number" style="width:20% !important" id="qac" disabled /><br/><br/>',
                            'Quota Capacity: <input type="number" style="width:20% !important" id="qc" disabled />',
                        '</div>',      
                      
                     '</span>',
              '</p>',
              

              
              '</div>',
              
              '<!-- Left Container Ends here-->',
               
               
             '<!-- RIght Container-->', 
               '<div class="modal-right-cont">',
                        
                     '<!--<span style="font-size:12px;">Filter <br/>', 
                        '<span class="text-input-pop">',
                            '<input type="text" class="text-add" />',
                        '</span>',
                    '</span>-->',   
               
                    '<table width="100%" cellpadding="0" cellspacing="0" class="modal-table" >',
                        
                        '<tr>',
                            '<th><input type="checkbox" onClick="toggle(this)"/></th>',
                            '<th>Username</th>',
                        '</tr>',
                        '<tr align="center">',
                            '<td><input type="checkbox" name="grp" /></td>',
                            '<td>admin</td>',
                        '</tr>',
                        '<tr align="center">',
                            '<td><input type="checkbox" name="grp" /></td>',
                            '<td>user1</td>',
                        '</tr>',
                    '</table>',
                    
                    '<p>Primary Group: <br/>', 
                    '<span class="text-input-pop">',
                        '<select id = "groups">',
                            groupListstr,             
                        '</select>',
                    '</span>',
              '</p>',
               '</div>',
             '<!-- Right Container Ends here-->',
             
             '</div>',
              
              
              '</div>',
            ];
             
             $("#user_create_inner").html(html.join(""));
             },
        error: function(){
            alert("ya");

        }
    });
        },
        
        show: {
            //effect: "blind",
            duration: 100
        },
        
        hide: {
            //effect: "explode",
            duration: 100
        },


        }).dialog( "open" );

}


confirmed =function(){

debugger;

var selDisk = [], inputList = $('input[name="disk_check"]:checked');

inputList.each(function(){
            selDisk.push(this.value);
        }
    );

var volume = {
    name: $("#vol_name").val(),
    rlevel: $("#select_raid").val(),
    size: $("#size").val(),
    secure: "0",
    block: "0",
    fs: $("#fs_type").val(),
    disk: selDisk.join(" "),
    fcache: "0"
};

console.log(volume);

createUser(JSON.stringify({ volume: volume }));

}

  getJSON = function(url) {
        var resp ;
        var xmlHttp ;

        resp  = '' ;
        xmlHttp = new XMLHttpRequest();

        if(xmlHttp != null)
        {
            xmlHttp.open( "GET", url, false );
            xmlHttp.send( null );
            resp = xmlHttp.responseText;
        }

        return resp ;
    }
   
// createUser =function(inpu){
//     //$.post("../create_volume/", {vol_name: inpu });
//     //$.ajax({
//     //    type: "POST",
//     //   url: "../create_volume/",
//     //    dataType: "json",
//     //    data: {
//             //csrfmiddlewaretoken: "{{ csrf_token }}",
//     //        vol_name: inpu
//     //    },
//      //   success: function(json){
//      //       document.write("done");
//         //}
//     //});
//     //alert(typeof(inpu));
// $.ajax({
//                  type:"POST",
//                  url:"../create_volume/",
//                  data: {
//                         //csrfmiddlewaretoken: "{{ csrf_token }}",
//                         vol_name: inpu // from form
//                         },
//                         //contentType: "application/text; charset=utf-8",
//     dataType: "text",
//     success: function(data) {
//         debugger;
//         $("#user_create").dialog('close');
//         $("#user-details").pqGrid("refreshDataAndView" );
//     },
//     error: function(data){
//         debugger;
//         alert("fail");
            
//             }
//         });
//            // return false;
// }
   
function enablequota() 
    {
    document.getElementById("qac").disabled=false;
    document.getElementById("qc").disabled=false;
    }

function disablequota() 
    {
    document.getElementById("qac").disabled=true;
    document.getElementById("qc").disabled=true;
    }
    
function confirmClicked(un,pg,em,pwd,desc) {
    var pass1 = document.getElementById("pass1").value;
    var pass2 = document.getElementById("pwd").value;
    var ok = true;
    if (pass1 != pass2) {
        alert("Passwords Do not match");
        document.getElementById("pass1").style.borderColor = "#E34234";
        document.getElementById("pwd").style.borderColor = "#E34234";
        document.getElementById("pwd").style.color = "#E34234";
        return;
    }
    else { 
          var quata_js = {
            disabled: "yes" ,
            quataAlert: "0",
            capacity: "0"
          };

          var user = {
            userName: un ,
            userId: "0",
            primaryGroup: pg ,
            groups: " ",
            email: em,
            passwd: pwd,
            description: desc,
            quata: quata_js

          };
          var final_js = { user : user};
          $.ajax({
                           type:"POST",
                           url:"../create_user/",
                           data: { string : JSON.stringify(final_js) },
                                  //contentType: "application/text; charset=utf-8",
              dataType: "text",
              success: function(data) {
                  debugger;
                  $("#user_create").dialog('close');
                  $("#user-details").pqGrid("refreshDataAndView" );
              },
              error: function(data){
                  debugger;
                  alert("fail");
                      
                      }
                  });
        //alert("Passwords Match!!!");
    }
    //return ;




}   

function toggle(source) {
  checkboxes = document.getElementsByName('grp');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}

function getUserRowIndx() {
            //var $grid = $("#grid_render_cells");

            //var obj = $grid.pqGrid("getSelection");
            //debugger;
            var $grid = $("#user-details");

            var arr = $grid.pqGrid("selection", {
                type: 'row',
                method: 'getSelection'
            });
            if (arr && arr.length > 0) {
                var rowIndx = arr[0].rowIndx;

                //if (rowIndx != null && colIndx == null) {
                return rowIndx;
            } else {
                alert("Select a row.");
                return null;
            }
        }
