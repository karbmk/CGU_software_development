sendEmail = function(){

				$.ajax({
        			type: 'GET',
        			url:"../email_send",

        			success: function(response){
            				
        			},
        			error: function(){

        			}
    			});
function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}
				sleep(10000);
				alert("Mail sent successfully");
}
